cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Cockpit Starter Kit": [
  null,
  "Cockpit Bausatz"
 ],
 "Running on $0": [
  null,
  "Läuft auf $0"
 ],
 "Starter Kit": [
  null,
  "Bausatz"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ]
});
