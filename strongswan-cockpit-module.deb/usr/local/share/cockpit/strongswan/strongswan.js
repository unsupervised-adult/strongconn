document.addEventListener('DOMContentLoaded', function () {
    console.log("DOM fully loaded and parsed.");

    ['load_all', 'list_sas', 'terminate_ike', 'list_client_pki', 'list_pki_files', 'generate_client', 'revoke_client', 'import_csv', 'debug_strongswan'].forEach(function (id) {
        var button = document.getElementById(id);
        if (button) {
            button.addEventListener('click', function () {
                console.log(id + ' button clicked');

                switch (id) {
                    case 'generate_client':
                        const email = document.getElementById('generate_email').value.trim();
                        const duration = document.getElementById('generate_duration').value.trim();

                        if (email && duration) {
                            cockpit.spawn(['sudo', '/usr/bin/ikpki.sh', 'generate-client', email, duration], { superuser: "require" })
                                .then(data => document.getElementById('output').innerText = `Client Certificate Generated:\n${data}`)
                                .catch(error => document.getElementById('output').innerText = `Failed to Generate Client Certificate:\n${error}`);
                        } else {
                            alert("Please provide both email and duration.");
                        }
                        break;

                    case 'revoke_client':
                        const revokeEmail = document.getElementById('revoke_email').value.trim();

                        if (revokeEmail) {
                            cockpit.spawn(['sudo', '/usr/bin/ikpki.sh', 'revoke-client', revokeEmail], { superuser: "require" })
                                .then(data => document.getElementById('output').innerText = `Client Certificate Revoked:\n${data}`)
                                .catch(error => document.getElementById('output').innerText = `Failed to Revoke Client Certificate:\n${error}`);
                        } else {
                            alert("Please provide the email of the client certificate to revoke.");
                        }
                        break;

                    case 'load_all':
                        cockpit.spawn(['sudo', 'swanctl', '--load-all'], { superuser: "require" })
                            .then(data => document.getElementById('output').innerText = `Loaded All Configurations:\n${data}`)
                            .catch(error => document.getElementById('output').innerText = `Failed to Load Configurations:\n${error}`);
                        break;

                    case 'list_sas':
                        cockpit.spawn(['sudo', 'swanctl', '--list-sas'], { superuser: "require" })
                            .then(data => document.getElementById('output').innerText = `Active Security Associations:\n${data}`)
                            .catch(error => document.getElementById('output').innerText = `Failed to List Security Associations:\n${error}`);
                        break;

                    case 'terminate_ike':
                        let ikeId = prompt("Enter IKE ID to terminate:");
                        if (ikeId) {
                            cockpit.spawn(['sudo', 'swanctl', '--terminate', '--ike', ikeId], { superuser: "require" })
                                .then(data => document.getElementById('output').innerText = `Terminated IKE ID ${ikeId}:\n${data}`)
                                .catch(error => document.getElementById('output').innerText = `Failed to Terminate IKE ID ${ikeId}:\n${error}`);
                        }
                        break;

                    case 'list_client_pki':
                        cockpit.spawn(['sudo', '/usr/bin/ikpki.sh', 'list'], { superuser: "require" })
                            .then(data => document.getElementById('output').innerText = `List Client Certificates:\n${data}`)
                            .catch(error => document.getElementById('output').innerText = `Failed to List Client Certificates:\n${error}`);
                        break;

                    case 'list_pki_files':
                        cockpit.spawn(['sudo', '/bin/ls', '-1', '/opt/pki'], { superuser: "require" })
                            .then(data => {
                                const files = data.split('\n').filter(file => file.trim().length > 0)
                                    .map(file => `<a href="/files/opt/pki/${file}" download>${file}</a><br/>`).join('');
                                document.getElementById('output').innerHTML = `PKI Files:<br/>${files}`;
                            })
                            .catch(error => document.getElementById('output').innerText = `Failed to List PKI Files:\n${error}`);
                        break;

                    case 'import_csv':
                            const csvInput = document.getElementById('csv_file_input');
                            csvInput.click(); // Open the file dialog when the button is clicked
                            
                            csvInput.onchange = () => {
                                const filePath = csvInput.files[0].path;
                                if (filePath) {
                                    cockpit.spawn(['sudo', '/usr/bin/ikpki.sh', 'import-csv', filePath], { superuser: "require" })
                                        .then(data => document.getElementById('output').innerText = `CSV Imported Successfully:\n${data}`)
                                        .catch(error => document.getElementById('output').innerText = `Failed to Import CSV:\n${error}`);
                                }
                            };
                            break;
                        
                    case 'debug_strongswan':
                        cockpit.spawn(['sudo', '/usr/bin/strongconn.sh', '-debug'], { superuser: "require" })
                            .then(data => document.getElementById('output').innerText = `Debug Output:\n${data}`)
                            .catch(error => document.getElementById('output').innerText = `Failed to Start Debugging:\n${error}`);
                        break;
                }
            });
        } else {
            console.error(`Button with ID ${id} does not exist.`);
        }
    });
});
