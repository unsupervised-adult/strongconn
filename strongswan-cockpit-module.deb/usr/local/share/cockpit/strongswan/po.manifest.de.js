cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Starter Kit": [
  null,
  "Bausatz"
 ]
});
